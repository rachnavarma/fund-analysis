﻿Build Application Instruction : 
Step 1: This Application is built in Java 8. Please use jdk 1.8 to run.
Step 2: Use Eclipse IDE 
        Right click on import →  choose existing maven project → Use fundanalysis folder to import → Click Finish

Run Application : 
Step 1: Keep the TestData folder at home/Documents folder.
(For Example : System.getProperty("user.home") + "/Documents/TestData/fund.csv")
Step 2: Run CsvWriteReadTest.java class to run the application


Unit Test Instruction :  Please Run FundAnalysisTest.java for test cases
There are two methods buildDummyDataList() and buildDummyDateList() which are used to prepare dummy data and has been called in setUp() method to be used.



Approach : 
1. Read Fund.csv file and construct fundList
2. Read FundReturnSeries.csv and BenchmarkReturnSeries.csv and construct a hashMap respectively which has ‘code’ as key and a returnSeries list as value which has the same code as key.
3. Loop through fundList, for every fundSeries Code and its related benchmarkSeries code prepare a MonthlyOutPerformance list where fundSeries date is same as benchmarkSeries date. Also compute excess and Out Performance to set it in MonthlyOutPerformance list
4. Sort MonthlyOutPerformance list in reverse date order
5. Filter sublist from MonthlyOutPerformance list based on date
6. Sort the sublist in reverse Return value and set the Rank value.
