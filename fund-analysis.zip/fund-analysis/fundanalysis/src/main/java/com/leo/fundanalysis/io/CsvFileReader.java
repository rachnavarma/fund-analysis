package com.leo.fundanalysis.io;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.leo.fundanalysis.algorithm.MonthlyPerformanceFactory;
import com.leo.fundanalysis.constant.AppConstant;
import com.leo.fundanalysis.domain.Funds;
import com.leo.fundanalysis.domain.MonthlyOutPerformance;
import com.leo.fundanalysis.domain.ReturnSeries;
import com.leo.fundanalysis.utility.BuilderUtil;

/**
 * @author rachna
 */
public class CsvFileReader {


	/**
	 * This method calls BuilderUtil class's methods to construct fundList from Fund file and HashMap from fundReturnSeries and benchmarkReturnSeries csv file
	 * calls the prepareMonthlyOutPerformance method to prepare computeMOPList list
	 * calls the sortListByDateReverseOrder method to sort the computeMOPList list in reverse date order
	 * then sort list by Return field and set the Rank based on Return value 
	 * 
	 * @param arr
	 * @return
	 */
	
	
	public static List<MonthlyOutPerformance> readCsvFiles(String fundFile, String fundReturnSeriesFile, String benchReturnSeriesFile) {
		MonthlyPerformanceFactory factory = new MonthlyPerformanceFactory();
		DateTimeFormatter fundDateformat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		DateTimeFormatter bmDateformat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		List<Funds> fundList = BuilderUtil.buildListFromFundFile(fundFile);
		Map<String, List<ReturnSeries>> benchmarkReturnMap = BuilderUtil.buildMapFromReturnSeriesFile(benchReturnSeriesFile, bmDateformat, AppConstant.BENCHMARK);
		Map<String, List<ReturnSeries>> fundReturnMap = BuilderUtil.buildMapFromReturnSeriesFile(fundReturnSeriesFile, fundDateformat, AppConstant.FUND );
		List<LocalDate> dateList = BuilderUtil.retrieveFundDateList();
		
		List<MonthlyOutPerformance> computeMOPList = new ArrayList<MonthlyOutPerformance>();
		fundList.forEach(fund -> {
			String fundCode = fund.getFundCode();
			String benchmarkCode = fund.getBenchmarkCode();
			factory.prepareMonthlyOutPerformance(computeMOPList, fundReturnMap.get(fundCode), benchmarkReturnMap.get(benchmarkCode), fund.getFundName());
		});
		factory.sortListByDateReverseOrder(computeMOPList);
		List<MonthlyOutPerformance> monthlyOutPerformanceList = factory.sortListByReturnToSetRank(computeMOPList, dateList);
		
		return monthlyOutPerformanceList;
	}

}
