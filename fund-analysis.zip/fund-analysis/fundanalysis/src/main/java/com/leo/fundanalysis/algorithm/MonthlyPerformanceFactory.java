package com.leo.fundanalysis.algorithm;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import com.leo.fundanalysis.constant.AppConstant;
import com.leo.fundanalysis.domain.MonthlyOutPerformance;
import com.leo.fundanalysis.domain.ReturnSeries;

/**
 * @author rachna
 */
public class MonthlyPerformanceFactory {

	/**
	 * This method uses the date to lookup the benchmark return from the benchmarkReturn ArrayList
	 * If the date matches with fund return date in fundReturnList then create the instance of MonthlyOutPerformance
	 * add the instance to the list
	 * @param arr
	 * @return
	 */
	
	public void prepareMonthlyOutPerformance(List<MonthlyOutPerformance> list,
			List<ReturnSeries> fundReturnList, List<ReturnSeries> benchmarkReturnList, String fundName) {
		fundReturnList.forEach(returnSeries -> {
			MonthlyOutPerformance monthlyOutPerformance = new MonthlyOutPerformance();
			benchmarkReturnList.forEach(bmReturnSeries -> {
				if (bmReturnSeries.getDate().isEqual(returnSeries.getDate())) {
					monthlyOutPerformance.setFundCode(returnSeries.getCode());
					monthlyOutPerformance.setFundReturn(returnSeries.getReturnVal());
					monthlyOutPerformance.setDate(returnSeries.getDate());
					monthlyOutPerformance.setFundName(fundName);
					double excess = calculateExcess(returnSeries.getReturnVal(), bmReturnSeries.getReturnVal());
					monthlyOutPerformance.setExcess(excess);
					String outPerformance = calculateOutPerformance(excess);
					monthlyOutPerformance.setOutPerformance(outPerformance);
					list.add(monthlyOutPerformance);
				}
			});
		});
	}

	
	/**
	* Subtract the benchmark return from the fund return to calculate the Excess.
	* 
	* @param double
	* @return
	*/			
	public double calculateExcess(double fundReturnVal, double bmReturnVal) {
		return fundReturnVal - bmReturnVal;
	}
	
	/**
	* Evaluate excess and generate OutPerformance
	* 
	* @param double
	* @return
	*/	
	public String calculateOutPerformance(double excess) {
		if (excess > 1)
			return AppConstant.OUTPERFORMED;
		else if (excess < -1)
			return AppConstant.UNDERPERFORMED;
		else
			return AppConstant.BLANK;
	}

	/**
	* Create DateComparator to sort the list in reversed date order
	* 
	* @param double
	* @return
	*/	
	public void sortListByDateReverseOrder(List<MonthlyOutPerformance> list) {
		Comparator<MonthlyOutPerformance> dateComparator = (k, v) -> k.getDate().compareTo(v.getDate());
		list.sort(dateComparator.reversed());
	}

	/**
	* Create a returnFundSort Comparator to sort the list based on Return Field
	* Use the dateList to retrieve the subgroup from the list based on date 
	* Sort the subgroup by using returnFundSort Comparator in reverse order
	* Set the Rank value for the subgroup using the index of subgroup list
	* 
	* @param double
	* @return
	*/	
	public List<MonthlyOutPerformance> sortListByReturnToSetRank(List<MonthlyOutPerformance> list, List<LocalDate> dateList) {
		List<MonthlyOutPerformance> resultList = new ArrayList<MonthlyOutPerformance>();
		Comparator<MonthlyOutPerformance> returnFundSort = (k, v) -> Double.compare(k.getFundReturn(), v.getFundReturn());
		
		dateList.forEach(date -> {
			List<MonthlyOutPerformance> monthDay = list.stream().filter(obj -> obj.getDate().isEqual(date))
					.collect(Collectors.toList());
			if (!monthDay.isEmpty()) {
				monthDay.sort(returnFundSort.reversed());
				IntStream.range(0, monthDay.size()).parallel().forEach(idx -> monthDay.get(idx).setRank(++idx));
				resultList.addAll(monthDay);
			}
		});
		return resultList;
	}

}
