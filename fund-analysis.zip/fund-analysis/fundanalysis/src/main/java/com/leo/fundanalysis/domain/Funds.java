package com.leo.fundanalysis.domain;

/**
 * @author rachna
 */
public class Funds {
	private String fundCode;
	private String fundName;
	private String benchmarkCode;

	public String getFundCode() {
		return fundCode;
	}

	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public String getBenchmarkCode() {
		return benchmarkCode;
	}

	public void setBenchmarkCode(String benchmarkCode) {
		this.benchmarkCode = benchmarkCode;
	}

	public String toString() {
		return "[ Funds : FundCode = "+fundCode + " FundName = " + fundName + " BenchMarkCode = " + benchmarkCode+" ]";
	}
}
